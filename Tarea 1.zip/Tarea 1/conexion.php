<?php

$host ="localhost";
$user="root";
$pass="";
$db = "guia 3";

$conexion = mysqli_connect($host, $user, $pass, $db   );
mysqli_set_charset($conexion, "utf8");

?>