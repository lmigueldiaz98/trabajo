<?php
include ("conexion.php");
	
	$Marca = $_POST['Marca'];
	$Linea = $_POST['Linea'];
	$Modelo = $_POST['Modelo'];
	$valor = $_POST['Valor'];

	$solicitud = "INSERT INTO Automoviles (Marca, Linea, Modelo) VALUES('$Marca','$Linea','$Modelo')";

	$resultado = mysqli_query($conexion, $solicitud);



	
 /* 
 · Entre 0 y 30 millones, pagan el 1,5% de impuesto.

· Más de 30 millones y hasta 70 millones, pagan el 2,0% de impuesto.

· Más de 70 millones y hasta 200 millones, pagan el 2,5% de impuesto.

· Más de 200 millones, pagan el 4% de impuesto. */

if ($valor < 30000000) {
     
    $impuesto = $impuesto + ($valor * 0.015);
    echo $impuesto;

 }
 if ($valor > 30000000 && $valor < 70000000) {
    $impuesto = $impuesto + ($valor * 0.020);
    echo $impuesto;

 }if ($valor > 70000000 && $valor>= 200000000){
     
    $impuesto = $impuesto + ($valor * 0.025);
    echo $impuesto;

 }
 if ($valor > 200000000 ) {
    $impuesto = $impuesto + ($valor * 0.04);
    echo $impuesto;
    
 }

?>

